//
//  HeaderCVC.swift
//  CustomStepperController
//


import UIKit

class HeaderCVC: UICollectionViewCell {
    
    @IBOutlet weak var lblTitle     : UILabel!
    @IBOutlet weak var bottomView   : UIView!
    
}
